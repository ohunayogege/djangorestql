ADD = "add"
CREATE = "create"
REMOVE = "remove"
UPDATE = "update"
